# Node Version
echo "Vertico is running on Mac OS"
echo "Node Version : " 
./bin/node --version 
echo "Npm Version : " 
./bin/npm --version 
./bin/npm  install